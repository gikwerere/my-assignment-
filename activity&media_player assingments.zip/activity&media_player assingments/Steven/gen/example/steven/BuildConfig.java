/** Automatically generated file. DO NOT MODIFY */
package example.steven;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}